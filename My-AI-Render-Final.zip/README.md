# My AI — Render + Ollama Cloud

## IMPORTANT SECURITY NOTE

This ZIP contains the `.env` with the API key because you specifically requested it.
**Do not upload this `.env` to a public GitHub repository.**

For production, put the secret in Render's Environment Variables instead.

## Render settings

Create a Render **Web Service** from this project.

Build command:
`npm install`

Start command:
`npm start`

Environment variables on Render:
- `OLLAMA_API_KEY` = your Ollama Cloud key
- `OLLAMA_MODEL` = `darealgriddy/myai`
- `OLLAMA_API_URL` = `https://ollama.com/api`

You do not need to expose the key to the browser. `server.js` reads it with `process.env.OLLAMA_API_KEY`.

## Keyboard
- Enter = send
- Shift+Enter = new line
- Ctrl+N = new chat

## GitHub
The repository should contain `.env.example`, not the real `.env`.
The included `.gitignore` ignores `.env`.

Because the key has already been shared in chat, rotate/revoke it before production.
